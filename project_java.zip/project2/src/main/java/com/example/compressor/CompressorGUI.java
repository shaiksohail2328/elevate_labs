package com.example.compressor;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class CompressorGUI extends JFrame {

    private final DefaultListModel<File> listModel = new DefaultListModel<>();
    private final JList<File> fileList = new JList<>(listModel);
    private final JProgressBar progressBar = new JProgressBar(0, 100);
    private final JTextArea logArea = new JTextArea(10, 50);

    public CompressorGUI() {
        super("File Compressor and Decompressor");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);

        initUI();
    }

    private void initUI() {
        JPanel top = new JPanel(new BorderLayout());

        fileList.setCellRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                if (value instanceof File) setText(((File) value).getAbsolutePath());
                return this;
            }
        });

        JScrollPane listScroll = new JScrollPane(fileList);
        top.add(listScroll, BorderLayout.CENTER);

        JPanel buttons = new JPanel();
        JButton addBtn = new JButton("Add Files/Folder");
        JButton removeBtn = new JButton("Remove");
        JButton compressBtn = new JButton("Compress");
        JButton decompressBtn = new JButton("Decompress ZIP");

        buttons.add(addBtn);
        buttons.add(removeBtn);
        buttons.add(compressBtn);
        buttons.add(decompressBtn);

        top.add(buttons, BorderLayout.SOUTH);

        add(top, BorderLayout.CENTER);

        JPanel bottom = new JPanel(new BorderLayout());
        progressBar.setStringPainted(true);
        bottom.add(progressBar, BorderLayout.NORTH);

        logArea.setEditable(false);
        JScrollPane logScroll = new JScrollPane(logArea);
        bottom.add(logScroll, BorderLayout.CENTER);

        add(bottom, BorderLayout.SOUTH);

        addBtn.addActionListener(this::onAdd);
        removeBtn.addActionListener(e -> {
            int idx = fileList.getSelectedIndex();
            if (idx >= 0) listModel.remove(idx);
        });
        compressBtn.addActionListener(e -> onCompress());
        decompressBtn.addActionListener(e -> onDecompress());
    }

    private void onAdd(ActionEvent e) {
        JFileChooser chooser = new JFileChooser();
        chooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
        chooser.setMultiSelectionEnabled(true);
        int res = chooser.showOpenDialog(this);
        if (res == JFileChooser.APPROVE_OPTION) {
            for (File f : chooser.getSelectedFiles()) listModel.addElement(f);
        }
    }

    private void onCompress() {
        if (listModel.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No files selected to compress.");
            return;
        }

        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Save ZIP file");
        chooser.setSelectedFile(new File("archive.zip"));
        int res = chooser.showSaveDialog(this);
        if (res != JFileChooser.APPROVE_OPTION) return;
        File out = chooser.getSelectedFile();

        List<File> files = new ArrayList<>();
        for (int i = 0; i < listModel.size(); i++) files.add(listModel.get(i));

        startCompression(files, out);
    }

    private void startCompression(List<File> files, File out) {
        progressBar.setValue(0);
        log("Starting compression to: " + out.getAbsolutePath());

        SwingWorker<Void, Integer> worker = new SwingWorker<>() {
            @Override
            protected Void doInBackground() throws Exception {
                File logsDir = new File("logs");
                logsDir.mkdirs();
                File logFile = new File(logsDir, "compression.log");
                try (BufferedWriter bw = new BufferedWriter(new FileWriter(logFile, true))) {
                    ZipUtils.compressFiles(files, out, percent -> publish(percent), bw);
                }
                return null;
            }

            @Override
            protected void process(List<Integer> chunks) {
                int p = chunks.get(chunks.size() - 1);
                progressBar.setValue(p);
            }

            @Override
            protected void done() {
                try { get(); log("Compression finished: " + out.getAbsolutePath()); }
                catch (Exception ex) { log("Compression failed: " + ex.getMessage()); JOptionPane.showMessageDialog(CompressorGUI.this, "Error: " + ex.getMessage()); }
                progressBar.setValue(100);
            }
        };
        worker.execute();
    }

    private void onDecompress() {
        JFileChooser chooser = new JFileChooser();
        chooser.setFileFilter(new FileNameExtensionFilter("ZIP files", "zip"));
        chooser.setDialogTitle("Select ZIP file to extract");
        int res = chooser.showOpenDialog(this);
        if (res != JFileChooser.APPROVE_OPTION) return;
        File zip = chooser.getSelectedFile();

        JFileChooser dest = new JFileChooser();
        dest.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        dest.setDialogTitle("Choose destination folder");
        int r2 = dest.showSaveDialog(this);
        if (r2 != JFileChooser.APPROVE_OPTION) return;
        File outDir = dest.getSelectedFile();

        startDecompression(zip, outDir);
    }

    private void startDecompression(File zip, File outDir) {
        progressBar.setValue(0);
        log("Starting decompression of: " + zip.getAbsolutePath());

        SwingWorker<Void, Integer> worker = new SwingWorker<>() {
            @Override
            protected Void doInBackground() throws Exception {
                File logsDir = new File("logs");
                logsDir.mkdirs();
                File logFile = new File(logsDir, "compression.log");
                try (BufferedWriter bw = new BufferedWriter(new FileWriter(logFile, true))) {
                    ZipUtils.decompress(zip, outDir, percent -> publish(percent), bw);
                }
                return null;
            }

            @Override
            protected void process(List<Integer> chunks) {
                int p = chunks.get(chunks.size() - 1);
                progressBar.setValue(p);
            }

            @Override
            protected void done() {
                try { get(); log("Decompression finished to: " + outDir.getAbsolutePath()); }
                catch (Exception ex) { log("Decompression failed: " + ex.getMessage()); JOptionPane.showMessageDialog(CompressorGUI.this, "Error: " + ex.getMessage()); }
                progressBar.setValue(100);
            }
        };
        worker.execute();
    }

    private void log(String s) {
        logArea.append(s + "\n");
        try (FileWriter fw = new FileWriter(new File("logs", "app.log"), true)) {
            fw.write(s + System.lineSeparator());
        } catch (IOException ignored) {}
    }
}
