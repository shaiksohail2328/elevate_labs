package com.example.compressor;

import javax.swing.SwingUtilities;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            CompressorGUI gui = new CompressorGUI();
            gui.setVisible(true);
        });
    }
}
