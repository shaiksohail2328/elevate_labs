package com.example.compressor;

import java.io.*;
import java.util.List;
import java.util.zip.*;

public class ZipUtils {

    public interface ProgressListener {
        void onProgress(int percent);
    }

    public static void compressFiles(List<File> files, File outputZip, ProgressListener listener, Appendable log) throws IOException {
        long totalBytes = 0L;
        for (File f : files) {
            if (f.isFile()) totalBytes += f.length();
            else totalBytes += folderSize(f);
        }

        final java.util.concurrent.atomic.AtomicLong bytesProcessed = new java.util.concurrent.atomic.AtomicLong(0L);
        long start = System.currentTimeMillis();

        try (ZipOutputStream zos = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(outputZip)))) {
            byte[] buffer = new byte[8192];
            for (File f : files) {
                if (f.isDirectory()) {
                    addDirectory(zos, f, f.getName() + File.separator, buffer, (count) -> {
                        long now = bytesProcessed.addAndGet(count);
                        notifyProgress(listener, totalBytes, now);
                    });
                } else {
                    try (InputStream in = new BufferedInputStream(new FileInputStream(f))) {
                        ZipEntry entry = new ZipEntry(f.getName());
                        entry.setTime(f.lastModified());
                        zos.putNextEntry(entry);
                        int len;
                        while ((len = in.read(buffer)) != -1) {
                            zos.write(buffer, 0, len);
                            long now = bytesProcessed.addAndGet(len);
                            notifyProgress(listener, totalBytes, now);
                        }
                        zos.closeEntry();
                    }
                }
            }
        }

        long elapsed = System.currentTimeMillis() - start;
        if (log != null) {
            try {
                log.append(String.format("Compressed %d files to %s in %d ms%n", files.size(), outputZip.getAbsolutePath(), elapsed));
            } catch (IOException ignored) {}
        }
    }

    private static void addDirectory(ZipOutputStream zos, File dir, String basePath, byte[] buffer, ProgressCallback cb) throws IOException {
        File[] children = dir.listFiles();
        if (children == null) return;
        for (File child : children) {
            if (child.isDirectory()) {
                addDirectory(zos, child, basePath + child.getName() + File.separator, buffer, cb);
            } else {
                try (InputStream in = new BufferedInputStream(new FileInputStream(child))) {
                    ZipEntry entry = new ZipEntry(basePath + child.getName());
                    entry.setTime(child.lastModified());
                    zos.putNextEntry(entry);
                    int len;
                    while ((len = in.read(buffer)) != -1) {
                        zos.write(buffer, 0, len);
                        cb.onBytes(len);
                    }
                    zos.closeEntry();
                }
            }
        }
    }

    private interface ProgressCallback { void onBytes(int count); }

    private static void notifyProgress(ProgressListener listener, long total, long processed) {
        if (listener == null || total <= 0) return;
        int p = (int) Math.min(100, (processed * 100) / total);
        listener.onProgress(p);
    }

    private static long folderSize(File folder) {
        long size = 0L;
        File[] files = folder.listFiles();
        if (files == null) return 0L;
        for (File f : files) {
            if (f.isFile()) size += f.length(); else size += folderSize(f);
        }
        return size;
    }

    public static void decompress(File zipFile, File targetDir, ProgressListener listener, Appendable log) throws IOException {
        long total = zipFile.length();
        long processed = 0L;
        long start = System.currentTimeMillis();

        try (ZipInputStream zis = new ZipInputStream(new BufferedInputStream(new FileInputStream(zipFile)))) {
            ZipEntry entry;
            byte[] buffer = new byte[8192];
            while ((entry = zis.getNextEntry()) != null) {
                File out = new File(targetDir, entry.getName());
                if (entry.isDirectory()) {
                    out.mkdirs();
                } else {
                    out.getParentFile().mkdirs();
                    try (OutputStream outStream = new BufferedOutputStream(new FileOutputStream(out))) {
                        int len;
                        while ((len = zis.read(buffer)) != -1) {
                            outStream.write(buffer, 0, len);
                            processed += len;
                            notifyProgress(listener, total, processed);
                        }
                    }
                }
                zis.closeEntry();
            }
        }

        long elapsed = System.currentTimeMillis() - start;
        if (log != null) {
            try { log.append(String.format("Decompressed %s to %s in %d ms%n", zipFile.getName(), targetDir.getAbsolutePath(), elapsed)); }
            catch (IOException ignored) {}
        }
    }
}
