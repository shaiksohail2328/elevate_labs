# File Compressor and Decompressor (Java Swing)

Simple desktop tool to compress and extract files using java.util.zip.

Features
- Select multiple files for compression
- Compress to a ZIP file
- Extract ZIP files to a chosen folder
- Progress bar and logs

Build

Requires Java 11+ and Maven.

From project root:

```powershell
mvn -U -DskipTests package
```

After successful build the executable JAR is in `target/file-compressor-1.0.0-jar-with-dependencies.jar`.

Run

```powershell
java -jar target/file-compressor-1.0.0-jar-with-dependencies.jar
```

Notes about demo video
- I cannot create a video file in this environment. To create a demo: start the app, select a few files, compress to a zip, delete originals or move and then decompress showing progress and log.
