# deploy-to-github.ps1 — Safe GitHub Deployment Script

$githubUser = Read-Host "Enter your GitHub username"
$repoName = Read-Host "Enter your repository name (existing or new)"
$branchName = "main"

Write-Host "Enter your Personal Access Token (PAT) below (it will not be shown):"
$securePAT = Read-Host -AsSecureString
$pat = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($securePAT))

# Initialize Git if needed
if (-not (Test-Path ".git")) {
    git init
    git branch -M $branchName
    Write-Host "✅ Initialized new Git repository."
}

git add .
git commit -m "Initial commit from PowerShell script" 2>$null
Write-Host "✅ Files added and committed."

# Set remote
$remoteUrl = "https://github.com/$githubUser/$repoName.git"
if ((git remote) -contains "origin") { git remote remove origin }
git remote add origin $remoteUrl
Write-Host "✅ Remote set to $remoteUrl"

# Push using PAT (securely)
Write-Host "⏳ Pushing to GitHub..."
$pushCommand = "git push -u https://${githubUser}:${pat}@github.com/${githubUser}/${repoName}.git ${branchName}"

Invoke-Expression $pushCommand

Write-Host "✅ Push complete! Repository URL:"
Write-Host "🌐 https://github.com/$githubUser/$repoName"
